---
title: "{{TITLE}}"
kind: "guide"
status: "draft"
path: "{{PATH}}"
persona: "user"
# version: ""
# order: 100
# tags: []
# applies-to: []
# related: []
---

# {{TITLE}}

<!-- Select an effective Persona with the `user` primitive from the built-in defaults plus valid project config. Set `persona` to that slug and write under `docs/assets/<persona-slug>/`. The built-in default is `user`. Either role can be human or agent; do not infer the audience from the author. -->

> See `.make-docs/system/contracts/guide-contract.md` for frontmatter schema, slug rules, audience rules, coverage decisions, and future coverage handling.

## Overview

What this guide helps users accomplish and who should start here.

## Before You Begin

What the user needs before they can follow the guide.

## Getting Started

The shortest path to a first successful outcome.

## Core Workflow

Step-by-step instructions for the primary user task.

## Advanced Usage

Optional deeper capabilities, variations, or next steps for experienced users.

## Troubleshooting

Common issues, expected symptoms, and how to resolve them.

## FAQ

Frequently asked questions.

## Related Resources

Links to related guides or deeper reference material.

<!--
## Future Coverage

Use this section only when confirmed downstream work should update this guide later.

- Blocked by: <phase, capability, decision, or artifact>
  Update when: <concrete trigger>
  Guide change: <what to add, revise, or remove>
-->

<!-- Headings above are suggestions. Add, remove, or rename sections to fit the guide's content while preserving the audience intent in the guide contract. -->
